<footer class="container-fluid text-center">
	<?php /*<div class="row">
		<div class="col-md-12 top-footer">
			
		</div><!-- /.top-footer -->*/ ?>
	<?php /*</div><!-- /.row -->*/ ?>
	
	<div class="row">
		<div class="col-md-12 bottom-footer">
			<p><small>designed by @n8rzz</small></p>
		</div><?php /*<!-- /.bottom-footer -->*/ ?>
	</div><?php /*<!-- /.row -->*/ ?>
</footer>

<?php wp_footer(); ?>

</body>
</html>