<?php /*<!-- COMMENTS -->*/ ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-12 comments-container">
			<h4>Comments</h4>
			<p class="post-comments"><?php the_title(); ?> has {x} comments</p>
			<ol class="commentlist">
				<li>
					<article class="comment">
						<img src="http://www.fillmurray.com/100/100" class="avatar" />
						<span class="comment-name">comment {name}</span> on <span class="comment-date">2/29/2000</span>
						<div class="comment-content">
							<p>Brisket bresaola andouille pork loin, spare ribs shoulder tail tri-tip beef <a href="#">tongue shank</a>a. Turducken pork belly brisket jowl spare ribs venison boudin short ribs capicola. Hamburger fatback ball tip, flank ground round chuck corned beef landjaeger pastrami capicola biltong sausage shoulder kevin pig.</p>
						</div><?php /*<!-- /.comment-content -->*/ ?>
					</article><?php /*<!-- /.comment -->*/ ?>
				</li>
				<li>
					<article class="comment">
						<img src="http://www.fillmurray.com/100/100" class="avatar" />
						<span class="comment-name">comment {name}</span> on <span class="comment-date">2/29/2000</span>
						<div class="comment-content">
							<p>Brisket bresaola andouille pork loin, spare ribs shoulder tail tri-tip beef <a href="#">tongue shank</a>a. Turducken pork belly brisket jowl spare ribs venison boudin short ribs capicola. Hamburger fatback ball tip, flank ground round chuck corned beef landjaeger pastrami capicola biltong sausage shoulder kevin pig.</p>
						</div><?php /*<!-- /.comment-content -->*/ ?>
					</article><?php /*<!-- /.comment -->*/ ?>
				</li>
				<li>
					<article class="comment">
						<img src="http://www.fillmurray.com/100/100" class="avatar" />
						<span class="comment-name">comment {name}</span> on <span class="comment-date">2/29/2000</span>
						<div class="comment-content">
							<p>Brisket bresaola andouille pork loin, spare ribs shoulder tail tri-tip beef <a href="#">tongue shank</a>a. Turducken pork belly brisket jowl spare ribs venison boudin short ribs capicola. Hamburger fatback ball tip, flank ground round chuck corned beef landjaeger pastrami capicola biltong sausage shoulder kevin pig.</p>
						</div><?php /*<!-- /.comment-content -->*/ ?>
					</article><?php /*<!-- /.comment -->*/ ?>
				</li>
			</ol><?php /*<!-- /.commentlist -->*/ ?>

		</div><?php /*<!-- /.comments-container -->*/ ?>
	</div><?php /*<!-- /.row -->*/ ?>
</div><?php /*<!-- /.container-fluid -->*/ ?>